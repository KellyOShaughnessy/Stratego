# Stratego
A6 - Robyn, Nikita, Kelly, Sarah

TO PROPERLY VIEW THE GAMEBOARD, PLEASE EXPAND YOUR TERMINAL WINDOW TO AT
MINIMUM 150x50 BEFORE STARTING


First compile : cs3110 compile gamestate.ml
then compile  : cs3110 compile ai.ml
then
TO COMPILE REPL USE: 'cs3110 compile -p str repl.ml'
AND THEN RUN: 'cs3110 run repl.ml'

INSTRUCTIONS WILL BEGIN AFTER THAT! ENJOY!
Note: If you do not want to manually place your 20 pieces on the game board,
you may type quickstart (after running repl). Quickstart will fill the board
with your pieces in the first two rows. It will also begin the game for you,
and you may begin to move your pieces and play against the computer.
